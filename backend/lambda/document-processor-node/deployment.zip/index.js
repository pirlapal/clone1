const AWS = require('aws-sdk');
const fs = require('fs');
const zlib = require('zlib');
const { execSync } = require('child_process');
const tar = require('tar');

const s3 = new AWS.S3();

exports.handler = async (event) => {
    try {
        const processedFiles = [];
        
        for (const record of event.Records) {
            const bucket = record.s3.bucket.name;
            const key = decodeURIComponent(record.s3.object.key.replace(/\+/g, ' '));
            
            console.log(`Processing file: s3://${bucket}/${key}`);
            
            if (!key.startsWith('uploads/')) {
                continue;
            }
            
            const fileExtension = key.toLowerCase().split('.').pop();
            const fileName = key.split('/').pop();
            const baseName = fileName.split('.').slice(0, -1).join('.');
            
            if (!await isFileSizeAcceptable(bucket, key)) {
                console.error(`File too large: ${fileName}`);
                continue;
            }
            
            if (['ppt', 'pptx'].includes(fileExtension)) {
                const pdfKey = await convertPptToPdf(bucket, key, baseName);
                if (pdfKey) {
                    processedFiles.push(pdfKey);
                    await s3.deleteObject({ Bucket: bucket, Key: key }).promise();
                    console.log(`Converted and deleted: ${key}`);
                }
            } else if (['pdf', 'txt', 'md', 'html', 'docx'].includes(fileExtension)) {
                const processedKey = `processed/${fileName}`;
                await s3.copyObject({
                    Bucket: bucket,
                    CopySource: `${bucket}/${key}`,
                    Key: processedKey
                }).promise();
                await s3.deleteObject({ Bucket: bucket, Key: key }).promise();
                processedFiles.push(processedKey);
            }
        }
        
        // Knowledge Base sync will be triggered automatically by S3 events
        if (processedFiles.length > 0) {
            console.log(`Processed ${processedFiles.length} files - KB sync will be triggered automatically`);
        }
        
        return {
            statusCode: 200,
            body: JSON.stringify({
                message: 'Processing completed',
                processedFiles: processedFiles.length
            })
        };
        
    } catch (error) {
        console.error('Error:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: error.message })
        };
    }
};

async function convertPptToPdf(bucket, pptKey, baseName) {
    const fileName = pptKey.split('/').pop();
    const inputFile = `/tmp/${fileName}`;
    
    try {
        // Download file from S3
        const params = { Bucket: bucket, Key: pptKey };
        const data = await s3.getObject(params).promise();
        fs.writeFileSync(inputFile, data.Body);
        
        // Extract LibreOffice if not already done
        const sofficebin = '/tmp/instdir/program/soffice.bin';
        if (!fs.existsSync(sofficebin)) {
            const compressed = fs.readFileSync('/opt/lo.tar.br');
            const decompressed = zlib.brotliDecompressSync(compressed);
            const tarFile = '/tmp/lo.tar';
            fs.writeFileSync(tarFile, decompressed);
            await tar.extract({ file: tarFile, cwd: '/tmp' });
            fs.unlinkSync(tarFile);
            fs.chmodSync(sofficebin, 0o755);
        }
        
        // Convert using LibreOffice
        execSync(`${sofficebin} --headless --convert-to pdf --outdir /tmp ${inputFile}`, { timeout: 240000 });
        
        // Upload PDF back to S3
        const pdfKey = `processed/${baseName}.pdf`;
        await s3.upload({
            Bucket: bucket,
            Key: pdfKey,
            Body: fs.createReadStream(outputFile),
            ContentType: 'application/pdf'
        }).promise();
        
        // Cleanup
        if (fs.existsSync(inputFile)) fs.unlinkSync(inputFile);
        if (fs.existsSync(outputFile)) fs.unlinkSync(outputFile);
        
        console.log(`Successfully converted: ${pdfKey}`);
        return pdfKey;
        
    } catch (error) {
        console.error('Conversion error:', error);
        // Cleanup on error
        if (fs.existsSync(inputFile)) fs.unlinkSync(inputFile);
        return null;
    }
}

async function isFileSizeAcceptable(bucket, key, maxMB = 50) {
    try {
        const headData = await s3.headObject({ Bucket: bucket, Key: key }).promise();
        const sizeMB = headData.ContentLength / (1024 * 1024);
        return sizeMB <= maxMB;
    } catch (error) {
        return false;
    }
}